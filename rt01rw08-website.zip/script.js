document.addEventListener("DOMContentLoaded", () => {
  console.log("Website RT 01 / RW 08 siap digunakan!");
});